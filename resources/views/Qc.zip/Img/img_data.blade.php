                                               

                                                <p>Folders Not Matched from SKUs: {{count($skuNotFound)}}</p>
                                                <ol>
                                                    <li><span class="revised-span" id="Revised1">{{$skuNotFound}}</span></li>
                                                    
                                                </ol>