<div class="col-12">
              <div class="form-group">
                <textarea class="form-control" name="invoiceInput" id="invoiceInput" cols="20" rows="5" placeholder="Enter invoice number"></textarea>
              </div>

              <input type="hidden" name="wrc" value="{{$wrc}}">