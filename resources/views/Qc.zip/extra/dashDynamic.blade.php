<div class="notification-flex-wrapper">
            <div class="notification-col notification-icon">
                <img src="dist\img\content-images\greenTick.svg" alt="Check">
            </div>
            <div class="notification-col notification-text">
                <h5>Billing</h5>
                <p>Invoice No {{$invoice}} fullfilled against WRC No {{$wrc_id}}</p>
            </div>
        </div>
